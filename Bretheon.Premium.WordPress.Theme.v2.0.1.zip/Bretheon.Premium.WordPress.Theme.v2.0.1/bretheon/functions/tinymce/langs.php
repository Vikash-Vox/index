<script type="text/javascript">
	tinyMCE.addI18n({en:{
		systempanel:{	
			desc : 'Theme shortcodes'
		}
	}
});
</script>